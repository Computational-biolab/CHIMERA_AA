#!/bin/bash
# CHIMERA_AA tool is designed by Dr.Pradeep Pant and Tushar Gupta.

echo -e "CHIMERA_AA - Protein Mutation Tool (ChimeraX Compatible)\n"

# Ask user for input PDB and output format
read -p "Enter PDB ID (e.g., 1ABC) or full local path to PDB file (e.g., C:\\\\Users\\\\Desktop\\\\chimera_AA\\\\1ABC.pdb): " pdb_input
read -p "Enter the desired format of the output file (.pdb / .cif / .mol2): " output_format

# Construct Chimera runCommand line
if [[ "$pdb_input" =~ ^[0-9a-zA-Z]{4}$ ]]; then
    pdb_input=$(echo "$pdb_input" | sed 's|\\|/|g')
    open_line="run(session, 'open "$pdb_input"')"
else
    pdb_input=$(echo "$pdb_input" | sed 's|\\|/|g')
    open_line="run(session, 'open "$pdb_input"')"
fi

echo -e "Enter '1' to perform mutations at single or multiple locations:\n\tTo generate user-specific mutations (maximum 10) in protein and their complexes (output: 1 file in the specified format)"
echo -e "Enter '2' to perform all possible class-wise amino-acid mutations at single or multiple locations:\n\tTo generate all combinations of user-specific class-wise amino-acid mutations (maximum 5 locations) in protein and their complexes (output: multiple files in the specified format)"

read -p "Enter your choice: " choice

echo "

Protein:
                   (Residue IDs)
            1  2  3  4  5  6  7  8  9 10 11 12
N-terminal  _  _  _  _  _  _  _  _  _  _  _  _  C-terminal  (ChainID: A)

#################################################################################################
# List of amino acids with their three letter codes (requied as an input)                       #
#                                                                                               #
# Alanine:        ALA      Arginine:      ARG      Asparagine:     ASN      Aspartic Acid:  ASP #
# Cysteine:       CYS      Glutamic Acid: GLU      Glutamine:      GLN      Glycine:        GLY #
# Histidine:      HIS      Isoleucine:    ILE      Leucine:        LEU      Lysine:         LYS #
# Methionine:     MET      Phenylalanine: PHE      Proline:        PRO      Serine:         SER #
# Threonine:      THR      Tryptophan:    TRP      Tyrosine:       TYR      Valine:         VAL #
#################################################################################################
"

# Start writing Python script
echo "import chimerax" > CHIMERA_AAx.py
echo "from chimerax.core.commands import run" >> CHIMERA_AAx.py
echo "$open_line" >> CHIMERA_AAx.py

case $choice in

1)
echo "		  
Depending on the argument1, user can generate upto 10 mutations in a output file of a protein or their complexes

argument1:  Number of mutations you want to introduce

CASE 1. If argument1 = 1 (only one mutation)
	then argument2: perform mutation at ChainID             : example A
	     argument3: perform mutation at residueID            : example 5
	     argument4: mutate the residue to GLY/ALA/VAL/..etc : example ALA
	     argument5: location where you want the output file, example: "'C:\\Users\\USER\\Desktop\\TEST\\'"
      
      Overall Syntax (example): 1 A 5 ALA "'C:\\Users\\USER\\Desktop\\TEST\\'"

CASE 2. If argument1 = 3 (three mutations)
   For mutation1:
   	argument2: perform mutation at ChainID                 : example A
	argument3: perform mutation at residueID                : example 5
	argument4: mutate the residue to GLY/ALA/VAL/..etc     : example ALA
	
  (It means mutate whatever residue is there at resID 5 to ALA in chain A)

   For mutation2:
       	 argument5: perform mutation at ChainID                : example A
	 argument6: perform mutation at residueID               : example 6
	 argument7: mutate the residue to GLY/ALA/VAL/..etc    : example GLY
   For mutation3:
       	 argument8: perform mutation at ChainID                : example A
	 argument9: perform mutation at residueID               : example 11
	 argument10: mutate the residue to GLY/ALA/VAL/..etc   : example SER
      argument11: location where you want the output file, example: "'C:\\Users\\USER\\Desktop\\TEST\\'"

    Overall Syntax (example): 3 A 5 ALA A 6 GLY A 11 SER C:\\\\Users\\\\USER\\\\Desktop\\\\TEST\\\\

"
read -r -a args
export output_format; ./multiplemf.sh "${args[@]}" "$output_format" >> CHIMERA_AAx.py
;;

2)
echo "
Depending on the argument1, user can generate all possible amino-acid class-wise  mutations at 1 to 5 (maximum) locations in their desired format of a protein or their complexes

# Display classes of amino acid

#######################################################################################################
# List of amino acids with their three letter codes (required as input) and class                     #
#                                                                                                     #
# HYDROPHOBIC (HYD)  AROMATIC      (ARO)   POLAR      (POL)   Basic     (BAS)   Acidic        (ACI)   #
# Alanine:     ALA   Phenylalanine: PHE    Serine:     SER    Lysine:    LYS    Aspartic Acid: ASP    #
# Valine :     VAL   Tyrosine:      TYR    Threonine:  THR    Arginine:  ARG    Glutamic Acid: GLU    #
# Leucine:     LEU   Tryptophan:    TRP    Cysteine:   CYS    Histidine: HIS                          #
# Isoleucine:  ILE                         Asparagine: ASN                                            #
# Glycine:     GLY                         Glutamine:  GLN                                            #
# Methionine:  MET                                                                                    # 
# Proline:     PRO                                                                                    #
#######################################################################################################

argument1:  Number of locations (maximum 5) at which you would like to introduce all possible class-wise amino-acid mutations

CASE 1. If argument1 = 1 (only one mutation)
        then argument2: mutate the residue to BAS/POL/HYD/..etc  : example POL
	      argument3: perform mutation at ChainID             : example A
	     argument4: perfom mutation at residueID             : example 5
	     argument5: location where you want the output files, example: "'C:\\Users\\USER\\Desktop\\TEST\\'"
      
      Overall Syntax (example): 1 POL A 5 "'C:\\Users\\USER\\Desktop\\TEST\\'"

CASE 2. If argument1 = 3 (three mutations)
   For mutation1:
   	argument2:  mutate the residue to BAS/POL/HYD/..etc      : example BAS
	argument3: perform mutation at ChainID                   : example A
	argument4: perfom mutation at residueID                  : example 5
	
  (It means mutate residue at resID 5 with all Charged amino acids in chain A)

   For mutation2:
        argument5:  mutate the residue to BAS/POL/HYD/..etc      : example POL
        argument6:  perform mutation at ChainID                  : example A
        argument7: perfom mutation at residueID                  : example 6
   For mutation3:
        argument8:  mutate the residue to BAS/POL/HYD/..etc      : example HYD
        argument9:  perform mutation at ChainID                  : example A
        argument10: perfom mutation at residueID                 : example 11
      argument11: location where you want the output files, example: "'C:\\Users\\USER\\Desktop\\TEST\\'"

    Overall Syntax (example): 3 BAS A 5 POL A 6 HYD A 11 "'C:\\Users\\USER\\Desktop\\TEST\\'"

"
read -r -a args
export output_format; ./combinationmf.sh "${args[@]}" "$output_format" >> CHIMERA_AAx.py
;;

*)
RED='\033[0;31m'
NC='\033[0m'
echo -e "${RED}Fatal Error: Please choose only among given options and enter '1' or '2'.${NC}"
exit 1
;;
esac

echo "
Your ChimeraX executable Python script has been saved as: CHIMERA_AAx.py

#################################################################################################################
# The code will automatically fetch your PDB structure from RCSB PDB when you enter the PDB ID  OR              #
# The code will import your pdb structure from the local system from the path you entered                       #
#                                                                                                               # 
# You may now execute your CHIMERA_AA.py file in Chimera 1.19 tool for applying desired mutations               #
# You may further execute the minimize.sh shell file using ./minimize.sh for obtaining python files to          #
# minimize your resulted structures by entering the path of folder in the mentioned template                    #
#################################################################################################################
"

