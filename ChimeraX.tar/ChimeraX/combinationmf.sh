#!/bin/bash

# Get the first and second arguments passed to the script
first_argument="$1"
second_argument="$2"

# Function to parse class.lib and get amino acids for a given class
get_amino_acids() {
    local class_name="$1"
    grep -w "$class_name" class.lib | cut -d' ' -f2-
}

#echo "import chimerax"
#echo "from chimerax.core.commands import run"
#echo "run(session, 'open 1KAO')"

# Generate commands based on the value of the first argument
case "$first_argument" in
    1)
        class1="$second_argument"
        amino_acids1=$(get_amino_acids "$class1")

        for aa1 in $amino_acids1; do
            echo "run(session, 'swapaa /$3:$4 $aa1 preserve 1;  save $5$aa1$4$3."$output_format"; ')"  #; $3-Chain; $4-residueID; $5-directory
        done
        ;;
    2)
        class1="$second_argument"
        class2="$5"
        amino_acids1=$(get_amino_acids "$class1")
        amino_acids2=$(get_amino_acids "$class2")

        for aa1 in $amino_acids1; do
            for aa2 in $amino_acids2; do
               echo "run(session, 'swapaa /$3:$4 $aa1 preserve 1; swapaa /$6:$7 $aa2 preserve 1; save $8$aa1$4$3$aa2$7$6".$output_format";')"
            done
        done
        ;;
    3)
        class1="$second_argument"
        class2="$5"
        class3="$8"
        amino_acids1=$(get_amino_acids "$class1")
        amino_acids2=$(get_amino_acids "$class2")
        amino_acids3=$(get_amino_acids "$class3")

        for aa1 in $amino_acids1; do
            for aa2 in $amino_acids2; do
                for aa3 in $amino_acids3; do
                   echo "run(session, 'swapaa /$3:$4 $aa1 preserve 1; swapaa /$6:$7 $aa2 preserve 1; swapaa /$9:${10} $aa3 preserve 1; save ${11}$aa1$4$3$aa2$7$6$aa3${10}$9".$output_format";')"
                done
            done
        done
        ;;
    4)
        class1="$second_argument"
        class2="$5"
        class3="$8"
        class4="${11}"
        amino_acids1=$(get_amino_acids "$class1")
        amino_acids2=$(get_amino_acids "$class2")
        amino_acids3=$(get_amino_acids "$class3")
        amino_acids4=$(get_amino_acids "$class4")

        for aa1 in $amino_acids1; do
            for aa2 in $amino_acids2; do
                for aa3 in $amino_acids3; do
                    for aa4 in $amino_acids4; do
                       echo "run(session, 'swapaa /$3:$4 $aa1 preserve 1; swapaa /$6:$7 $aa2 preserve 1; swapaa /$9:${10} $aa3 preserve 1; swapaa /${12}:${13} $aa4 preserve 1; save ${14}$aa1$4$3$aa2$7$6$aa3${10}$9$aa4${13}${12}."$output_format";')"
                    done
                done
            done
        done
        ;;
    5)
        class1="$second_argument"
        class2="$5"
        class3="$8"
        class4="${11}"
        class5="${14}"
        amino_acids1=$(get_amino_acids "$class1")
        amino_acids2=$(get_amino_acids "$class2")
        amino_acids3=$(get_amino_acids "$class3")
        amino_acids4=$(get_amino_acids "$class4")
        amino_acids5=$(get_amino_acids "$class5")

        for aa1 in $amino_acids1; do
            for aa2 in $amino_acids2; do
                for aa3 in $amino_acids3; do
                    for aa4 in $amino_acids4; do
                        for aa5 in $amino_acids5; do
                           echo "run(session, 'swapaa /$3:$4 $aa1 preserve 1; swapaa /$6:$7 $aa2 preserve 1; swapaa /$9:${10} $aa3 preserve 1; swapaa /${12}:${13} $aa4 preserve 1; swapaa /${15}:${16} $aa5 preserve 1; save ${17}$aa1$4$3$aa2$7$6$aa3${10}$9$aa4$${13}{12}$aa5${16}${15}."$output_format";')"
                        done
                    done
                done
            done
        done
        ;;
    *)
        echo "Invalid input. Please provide correct arguments."
        exit 1
        ;;
esac

