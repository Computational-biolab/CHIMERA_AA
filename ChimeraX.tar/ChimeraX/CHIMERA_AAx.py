import chimerax
from chimerax.core.commands import run
run(session, 'open C:/Users/Desktop/chimera_AA/1ABC.pdb')
run(session, 'swapaa /A:10 ALA preserve 1; swapaa /B:12 VAL preserve 1; swapaa /C:23 GLY preserve 1 ; save C:\\Users\\Desktop\\testALA10VAL12GLY23..mol2;')
