import chimera
from chimera import runCommand
runCommand('open D:\\pdb files\\1HFZ_A.pdb')
runCommand(u'swapaa ASP :82.A preserve true; swapaa ASP :88.A preserve true; swapaa ASP :87.A preserve true; write 0 C:\\Users\\Dell\\OneDrive\\Desktop\\pdb\\ASP82ASP88ASP87.pdb;')
runCommand(u'swapaa ASP :82.A preserve true; swapaa ASP :88.A preserve true; swapaa GLU :87.A preserve true; write 0 C:\\Users\\Dell\\OneDrive\\Desktop\\pdb\\ASP82ASP88GLU87.pdb;')
runCommand(u'swapaa ASP :82.A preserve true; swapaa GLU :88.A preserve true; swapaa ASP :87.A preserve true; write 0 C:\\Users\\Dell\\OneDrive\\Desktop\\pdb\\ASP82GLU88ASP87.pdb;')
runCommand(u'swapaa ASP :82.A preserve true; swapaa GLU :88.A preserve true; swapaa GLU :87.A preserve true; write 0 C:\\Users\\Dell\\OneDrive\\Desktop\\pdb\\ASP82GLU88GLU87.pdb;')
runCommand(u'swapaa GLU :82.A preserve true; swapaa ASP :88.A preserve true; swapaa ASP :87.A preserve true; write 0 C:\\Users\\Dell\\OneDrive\\Desktop\\pdb\\GLU82ASP88ASP87.pdb;')
runCommand(u'swapaa GLU :82.A preserve true; swapaa ASP :88.A preserve true; swapaa GLU :87.A preserve true; write 0 C:\\Users\\Dell\\OneDrive\\Desktop\\pdb\\GLU82ASP88GLU87.pdb;')
runCommand(u'swapaa GLU :82.A preserve true; swapaa GLU :88.A preserve true; swapaa ASP :87.A preserve true; write 0 C:\\Users\\Dell\\OneDrive\\Desktop\\pdb\\GLU82GLU88ASP87.pdb;')
runCommand(u'swapaa GLU :82.A preserve true; swapaa GLU :88.A preserve true; swapaa GLU :87.A preserve true; write 0 C:\\Users\\Dell\\OneDrive\\Desktop\\pdb\\GLU82GLU88GLU87.pdb;')
