#!/bin/bash

echo -e "Enter 1 to perform mutations at single or multiple locations:\n			To generate user-specific mutations (maximum 10) in protein and their complexes (output: 1 PDB)"
echo -e "Enter 2 to perform amino-acid class-wise all possible mutations at single or multiple locations:\n			To generate all combinations of user-specific amino-acid class-wise mutations (maximum 5 locations) in protein and their complexes (output: multiple PDBs)"

read -p "Enter your choice: " choice
echo "

Protein:
	               (Residue IDs)
            1  2  3  4  5  6  7  8  9 10 11 12
N-terminal  _  _  _  _  _  _  _  _  _  _  _  _  C-terminal  (ChainID: A)

#################################################################################################
# List of amino acids with their three letter codes (requied as an input)	          	#									#
#												#			
# Alanine:        ALA      Arginine:      ARG      Asparagine:     ASN      Aspartic Acid:  ASP #
# Cysteine:       CYS      Glutamic Acid: GLU      Glutamine:      GLN      Glycine:        GLY #
# Histidine:      HIS      Isoleucine:    ILE      Leucine:        LEU      Lysine:         LYS #
# Methionine:     MET      Phenylalanine: PHE      Proline:        PRO      Serine:         SER #
# Threonine:      THR      Tryptophan:    TRP      Tyrosine:       TYR      Valine:         VAL #
#################################################################################################
"

case $choice in

1)
echo "		  
Depending on the argument1, user can generate 1 to 10 (maximum) mutations in a PDB file of a protein or their complexes

argument1:  Number of mutations you want to introduce

CASE 1. If argument1 = 1 (only one mutation)
	then argument2: mutate the residue to GLY/ALA/VAL/..etc: example ALA
	     argument3: perform mutation at residueID           : example 5
	     argument4: perform mutation at ChainID            : example A
	     argument5: location where you want the output PDB, example: "'C:\\Users\\pradeep\\Desktop\\TEST\\'"
      Overall Syntax (example): 1 ALA 5 A "'C:\\Users\\pradeep\\Desktop\\TEST\\'"

CASE 2. If argument1 = 3 (three mutations)
   For mutation1:
   	argument2:  mutate the residue to GLY/ALA/VAL/..etc : example ALA
	argument3:  perform mutation at residueID            : example 5
	argument4:  perform mutation at ChainID             : example A
	(It means mutate whatever residue is there at resID 5 to ALA in chain A)

   For mutation2:
        argument5:  mutate the residue to GLY/ALA/VAL/..etc : example GLY
        argument6:  perform mutation at residueID  	    : example 6
        argument7:  perform mutation at ChainID             : example A

   For mutation3:
        argument8:  mutate the residue to GLY/ALA/VAL/..etc : example SER
        argument9:  perform mutation at residueID            : example 11
        argument10: perform mutation at ChainID             : example A
      argument11: location where you want the output PDB, example: "'C:\\Users\\pradeep\\Desktop\\TEST\\'"

    Overall Syntax (example): 3 ALA 5 A GLY 6 A SER 11 A "'C:\\Users\\pradeep\\Desktop\\TEST\\'"

"
read -r -a args
./multi.sh "${args[@]}" > CHIMERA_AA.py
;;

2)
echo "
Depending on the argument1, user can generate all possible amino-acid class-wise  mutations at 1 to 5 (maximum) locations in a PDB file of a protein or their complexes

argument1:  Number of locations (maximum 5) at which you would like to introduce all possible amino-acid class-wise  mutations

CASE 1. If argument1 = 1 (only one mutation)
        then argument2: mutate the residue to CHR/POL/HYD/..etc: example POL
	     argument3: perform mutation at residueID           : example 5
	     argument4: perform mutation at ChainID            : example A
	     argument5: location where you want the output PDB, example: "'C:\\Users\\pradeep\\Desktop\\TEST\\'"
      Overall Syntax (example): 1 POL 5 A "'C:\\Users\\pradeep\\Desktop\\TEST\\'"

CASE 2. If argument1 = 3 (three mutations)
   For mutation1:
   	argument2:  mutate the residue to CHR/POL/HYD/..etc : example CHR
	argument3:  perform mutation at residueID            : example 5
	argument4:  perform mutation at ChainID             : example A
	(It means mutate whatever residue is there at resID 5 to ALA in chain A)

   For mutation2:
        argument5:  mutate the residue to CHR/POL/HYD/..etc : example POL
        argument6:  perform mutation at residueID  	    : example 6
        argument7:  perform mutation at ChainID             : example A

   For mutation3:
        argument8:  mutate the residue to CHR/POL/HYD/..etc : example HYD
        argument9:  perform mutation at residueID            : example 11
        argument10: perform mutation at ChainID             : example A
      argument11: location where you want the output PDB, example: "'C:\\Users\\pradeep\\Desktop\\TEST\\'"

    Overall Syntax (example): 3 CHR 5 A POL 6 A HYD 11 A "'C:\\Users\\pradeep\\Desktop\\TEST\\'"

"
read -r -a args
sh combination.sh "${args[@]}" > CHIMERA_AA.py
;;

*)
RED='\033[0;31m'
NC='\033[0m'
echo -e "${RED}Fatel Error: Please enter 1 OR 2${NC}"
#echo "Invalid choice. Please enter 1 OR 2 OR 3 OR 4"
exit 1
;;
esac
echo " Your input python script (CHIMERA_AA.py) is ready for Chimera 

			      ########################	
###############################                      ####################################
#                             #  YOUR INPUT PDB FILE #  		   	        #
#			      # 		     #					#
#			      ########################				        #
#										        #
# If you want to download your PDB of interest from RCSB webserver:                	#
#     on line #3 of CHIMERA_AA.py, change 1KAO to your PDB ID			   	#
#										   	#
# If you have your desired PDB file in your local directory:			   	#
#     on line #3 of CHIMERA_AA.py, change 1KAO to your directory location	  	#
#     for example: runCommand("'open C:\\Users\\pradeep\\Desktop\\1KAO.pdb'")     	#
#										   	#
#########################################################################################
"
