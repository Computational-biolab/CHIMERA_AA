#!/bin/bash

# Get the first and second arguments passed to the script
first_argument="$1"
second_argument="$2"

# Function to parse class.lib and get amino acids for a given class
get_amino_acids() {
    local class_name="$1"
    grep -w "$class_name" class.lib | cut -d' ' -f2-
}

echo "import chimera"
echo "from chimera import runCommand"
echo "runCommand('open 1KAO')"

# Generate commands based on the value of the first argument
case "$first_argument" in
    1)
        class1="$second_argument"
        amino_acids1=$(get_amino_acids "$class1")

        for aa1 in $amino_acids1; do
            echo "runCommand(u'swapaa $aa1 :$3.$4 preserve true; write 0 $5$aa1$3.pdb;')"  # $3-aaRES; $4-aaID; $5-chain; $6-directory
        done
        ;;
    2)
        class1="$second_argument"
        class2="$5"
        amino_acids1=$(get_amino_acids "$class1")
        amino_acids2=$(get_amino_acids "$class2")

        for aa1 in $amino_acids1; do
            for aa2 in $amino_acids2; do
                echo "runCommand(u'swapaa $aa1 :$3.$4 preserve true; swapaa $aa2 :$6.$7 preserve true; write 0 $8$aa1$3$aa2$6.pdb;')"
            done
        done
        ;;
    3)
        class1="$second_argument"
        class2="$5"
        class3="$8"
        amino_acids1=$(get_amino_acids "$class1")
        amino_acids2=$(get_amino_acids "$class2")
        amino_acids3=$(get_amino_acids "$class3")

        for aa1 in $amino_acids1; do
            for aa2 in $amino_acids2; do
                for aa3 in $amino_acids3; do
                    echo "runCommand(u'swapaa $aa1 :$3.$4 preserve true; swapaa $aa2 :$6.$7 preserve true; swapaa $aa3 :$9.${10} preserve true; write 0 ${11}$aa1$3$aa2$6$aa3$9.pdb;')"
                done
            done
        done
        ;;
    4)
        class1="$second_argument"
        class2="$5"
        class3="$8"
        class4="${11}"
        amino_acids1=$(get_amino_acids "$class1")
        amino_acids2=$(get_amino_acids "$class2")
        amino_acids3=$(get_amino_acids "$class3")
        amino_acids4=$(get_amino_acids "$class4")

        for aa1 in $amino_acids1; do
            for aa2 in $amino_acids2; do
                for aa3 in $amino_acids3; do
                    for aa4 in $amino_acids4; do
                        echo "runCommand(u'swapaa $aa1 :$3.$4 preserve true; swapaa $aa2 :$6.$7 preserve true; swapaa $aa3 :$9.${10} preserve true; swapaa $aa4 :${12}.${13} preserve true; write 0 ${14}$aa1$3$aa2$6$aa3$9$aa4${12}.pdb;')"
                    done
                done
            done
        done
        ;;
    5)
        class1="$second_argument"
        class2="$5"
        class3="$8"
        class4="${11}"
        class5="${14}"
        amino_acids1=$(get_amino_acids "$class1")
        amino_acids2=$(get_amino_acids "$class2")
        amino_acids3=$(get_amino_acids "$class3")
        amino_acids4=$(get_amino_acids "$class4")
        amino_acids5=$(get_amino_acids "$class5")

        for aa1 in $amino_acids1; do
            for aa2 in $amino_acids2; do
                for aa3 in $amino_acids3; do
                    for aa4 in $amino_acids4; do
                        for aa5 in $amino_acids5; do
                            echo "runCommand(u'swapaa $aa1 :$3.$4 preserve true; swapaa $aa2 :$6.$7 preserve true; swapaa $aa3 :$9.${10} preserve true; swapaa $aa4 :${12}.${13} preserve true; swapaa $aa5 :${15}.${16} preserve true; write 0 ${17}$aa1$3$aa2$6$aa3$9$aa4${12}$aa5${15}.pdb;')"
                        done
                    done
                done
            done
        done
        ;;
    *)
        echo "Invalid input. Please provide correct arguments."
        exit 1
        ;;
esac
