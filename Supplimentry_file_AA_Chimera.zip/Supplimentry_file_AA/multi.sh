#!/bin/bash


# Get the first argument passed to the script (number of mutations you would like to have)
  first_argument="$1"

echo "import chimera"
echo "from chimera import runCommand"
echo "runCommand('open 1KAO')"

#echo "runCommand(u'swapaa\xa0A :$1.$9 preserve true; swapaa\xa0A :$2.$9 preserve true; swapaa\xa0A :$3.$9 preserve true; swapaa\xa0A :$4.$9 preserve true; swapaa\xa0T :$5.${10} preserve true; swapaa\xa0T :$6.${10} preserve true; swapaa\xa0T :$7.${10} preserve true; swapaa\xa0T :$8.${10} preserve true; write 0 ${11}AAAA.pdb;')"


# Check the value of the first argument and print accordingly
if [ "$first_argument" -eq 1 ]; then
  echo "runCommand(u'swapaa\xa0$2 :$3.$4 preserve true; write 0 $5$2$3.pdb;')"  #$2-aaRES; $3-aaID; $4-chain; $5-directory

elif [ "$first_argument" -eq 2 ]; then
  echo "runCommand(u'swapaa\xa0$2 :$3.$4 preserve true; swapaa\xa0$5 :$6.$7 preserve true; write 0 $8$2$3$5$6.pdb;')"

elif [ "$first_argument" -eq 3 ]; then
  echo "runCommand(u'swapaa\xa0$2 :$3.$4 preserve true; swapaa\xa0$5 :$6.$7 preserve true; swapaa\xa0$8 :$9.${10} preserve true ; write 0 ${11}$2$3$5$6$8$9.pdb;')"

elif [ "$first_argument" -eq 4 ]; then
  echo "runCommand(u'swapaa\xa0$2 :$3.$4 preserve true; swapaa\xa0$5 :$6.$7 preserve true; swapaa\xa0$8 :$9.${10} preserve true ; swapaa\xa0${11} :${12}.${13} preserve true; write 0 ${14}$2$3$5$6$8$9${11}${12}.pdb;')"

elif [ "$first_argument" -eq 5 ]; then
  echo "runCommand(u'swapaa\xa0$2 :$3.$4 preserve true; swapaa\xa0$5 :$6.$7 preserve true; swapaa\xa0$8 :$9.${10} preserve true ; swapaa\xa0${11} :${12}.${13} preserve true; swapaa\xa0${14} :${15}.${16} preserve true ;write 0 ${17}$2$3$5$6$8$9${11}${12}${14}${15}.pdb;')"

elif [ "$first_argument" -eq 6 ]; then
  echo "runCommand(u'swapaa\xa0$2 :$3.$4 preserve true; swapaa\xa0$5 :$6.$7 preserve true; swapaa\xa0$8 :$9.${10} preserve true ; swapaa\xa0${11} :${12}.${13} preserve true; swapaa\xa0${14} :${15}.${16} preserve true ; swapaa\xa0${17} :${18}.${19} preserve true; write 0 ${20}$2$3$5$6$8$9${11}${12}${14}${15}${17}${18}.pdb;')"

elif [ "$first_argument" -eq 7 ]; then
  echo "runCommand(u'swapaa\xa0$2 :$3.$4 preserve true; swapaa\xa0$5 :$6.$7 preserve true; swapaa\xa0$8 :$9.${10} preserve true ; swapaa\xa0${11} :${12}.${13} preserve true; swapaa\xa0${14} :${15}.${16} preserve true ; swapaa\xa0${17} :${18}.${19} preserve true; swapaa\xa0${20} :${21}.${22} preserve true ;write 0 ${23}$2$3$5$6$8$9${11}${12}${14}${15}${17}${18}${20}${21}.pdb;')"

elif [ "$first_argument" -eq 8 ]; then
  echo "runCommand(u'swapaa\xa0$2 :$3.$4 preserve true; swapaa\xa0$5 :$6.$7 preserve true; swapaa\xa0$8 :$9.${10} preserve true ; swapaa\xa0${11} :${12}.${13} preserve true; swapaa\xa0${14} :${15}.${16} preserve true ; swapaa\xa0${17} :${18}.${19} preserve true; swapaa\xa0${20} :${21}.${22} preserve true ; swapaa\xa0${23} :${24}.${25} preserve true ; write 0 ${26}$2$3$5$6$8$9${11}${12}${14}${15}${17}${18}${20}${21}${23}${24}.pdb;')"

elif [ "$first_argument" -eq 9 ]; then
  echo "runCommand(u'swapaa\xa0$2 :$3.$4 preserve true; swapaa\xa0$5 :$6.$7 preserve true; swapaa\xa0$8 :$9.${10} preserve true ; swapaa\xa0${11} :${12}.${13} preserve true; swapaa\xa0${14} :${15}.${16} preserve true ; swapaa\xa0${17} :${18}.${19} preserve true; swapaa\xa0${20} :${21}.${22} preserve true ; swapaa\xa0${23} :${24}.${25} preserve true ; swapaa\xa0${26} :${27}.${28} preserve true ; write 0 ${29}$2$3$5$6$8$9${11}${12}${14}${15}${17}${18}${20}${21}${23}${24}${26}${27}.pdb;')"

elif [ "$first_argument" -eq 10 ]; then
  echo "runCommand(u'swapaa\xa0$2 :$3.$4 preserve true; swapaa\xa0$5 :$6.$7 preserve true; swapaa\xa0$8 :$9.${10} preserve true ; swapaa\xa0${11} :${12}.${13} preserve true; swapaa\xa0${14} :${15}.${16} preserve true ; swapaa\xa0${17} :${18}.${19} preserve true; swapaa\xa0${20} :${21}.${22} preserve true ; swapaa\xa0${23} :${24}.${25} preserve true ; swapaa\xa0${26} :${27}.${28} preserve true ;swapaa\xa0${29} :${30}.${31} preserve true ; write 0 ${31}$2$3$5$6$8$9${11}${12}${14}${15}${17}${18}${20}${21}${23}${24}${26}${27}${29}${30}.pdb;')"

else

echo "Invalid input. Please provide arguments."
            exit 1
            fi

