import chimera
from chimera import runCommand
runCommand('open D:\\pdb_files\\protein-drug.pdb')
runCommand(u'swapaa LYS :18.A preserve true; write 0 C:\\Users\\Dell\\OneDrive\\Desktop\\pdb\\LYS18.pdb;')
runCommand(u'swapaa ARG :18.A preserve true; write 0 C:\\Users\\Dell\\OneDrive\\Desktop\\pdb\\ARG18.pdb;')
runCommand(u'swapaa HIS :18.A preserve true; write 0 C:\\Users\\Dell\\OneDrive\\Desktop\\pdb\\HIS18.pdb;')
