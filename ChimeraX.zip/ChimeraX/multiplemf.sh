#!/bin/bash


# Get the first argument passed to the script (number of mutations you would like to have)
first_argument="$1"

#echo "import chimerax"
#echo "from chimerax.core.commands import run"
#echo "run(session, 'open 1HUS')"

# Check the value of the first argument and print accordingly
if [ "$first_argument" -eq 1 ]; then
  echo "run(session, 'swapaa /$2:$3 $4 preserve 1; save $5$4$3."$output_format"; ')"  #$2-chainID; $3-residueID; $4-aaName; $5-directory

elif [ "$first_argument" -eq 2 ]; then
  echo "run(session, 'swapaa /$2:$3 $4 preserve 1; swapaa /$5:$6 $7 preserve 1; save $8$4$3$7$6."$output_format";')"

elif [ "$first_argument" -eq 3 ]; then
  echo "run(session, 'swapaa /$2:$3 $4 preserve 1; swapaa /$5:$6 $7 preserve 1; swapaa /$8:$9 ${10} preserve 1 ; save ${11}$4$3$7$6${10}$9."$output_format";')"

elif [ "$first_argument" -eq 4 ]; then
  echo "run(session, 'swapaa /$2:$3 $4 preserve 1; swapaa /$5:$6 $7 preserve 1; swapaa /$8:$9 ${10} preserve 1 ; swapaa /${11}:${12} ${13} preserve 1; save ${14}$4$3$7$6${10}$9${13}${12}."$output_format";')"

elif [ "$first_argument" -eq 5 ]; then
  echo "run(session, 'swapaa /$2:$3 $4 preserve 1; swapaa /$5:$6 $7 preserve 1; swapaa /$8:$9 ${10} preserve 1 ; swapaa /${11}:${12} ${13} preserve 1; swapaa /${14}:${15} ${16} preserve 1 ;save ${17}$4$3$7$6${10}$9${13}${12}${16}${15}."$output_format";')"

elif [ "$first_argument" -eq 6 ]; then
  echo "run(session, 'swapaa /$2:$3 $4 preserve 1; swapaa /$5:$6 $7 preserve 1; swapaa /$8:$9 ${10} preserve 1 ; swapaa /${11}:${12} ${13} preserve 1; swapaa /${14}:${15} ${16} preserve 1 ; swapaa /${17}:${18} ${19} preserve 1; save ${20}$4$3$7$6${10}$9${13}${12}${16}${15}${19}${18}."$output_format";')"

elif [ "$first_argument" -eq 7 ]; then
  echo "run(session, 'swapaa /$2:$3 $4 preserve 1; swapaa /$5:$6 $7 preserve 1; swapaa /$8:$9 ${10} preserve 1 ; swapaa /${11}:${12} ${13} preserve 1; swapaa /${14}:${15} ${16} preserve 1 ; swapaa /${17}:${18} ${19} preserve 1; swapaa /${20}:${21} ${22} preserve 1 ;save ${23}$4$3$7$6${10}$9${13}${12}${16}${15}${19}${18}${22}${21}."$output_format";')"

elif [ "$first_argument" -eq 8 ]; then
  echo "run(session, 'swapaa /$2:$3 $4 preserve 1; swapaa /$5:$6 $7 preserve 1; swapaa /$8:$9 ${10} preserve 1 ; swapaa /${11}:${12} ${13} preserve 1; swapaa /${14}:${15} ${16} preserve 1 ; swapaa /${17}:${18} ${19} preserve 1; swapaa /${20}:${21} ${22} preserve 1 ; swapaa /${23}:${24} ${25} preserve 1 ; save ${26}$4$3$7$6${10}$9${13}${12}${16}${15}${19}${18}${22}${21}${25}${24}."$output_format";')"

elif [ "$first_argument" -eq 9 ]; then
  echo "run(session, 'swapaa /$2:$3 $4 preserve 1; swapaa /$5:$6 $7 preserve 1; swapaa /$8:$9 ${10} preserve 1 ; swapaa /${11}:${12} ${13} preserve 1; swapaa /${14}:${15} ${16} preserve 1 ; swapaa /${17}:${18} ${19} preserve 1; swapaa /${20}:${21} ${22} preserve 1 ; swapaa /${23}:${24} ${25} preserve 1 ; swapaa /${26}:${27} ${28} preserve 1 ; save ${29}$4$3$7$6${10}$9${13}${12}${16}${15}${19}${18}${22}${21}${25}${24}${28}${27}."$output_format";')"

elif [ "$first_argument" -eq 10 ]; then
  echo "run(session, 'swapaa /$2:$3 $4 preserve 1; swapaa /$5:$6 $7 preserve 1; swapaa /$8:$9 ${10} preserve 1 ; swapaa /${11}:${12} ${13} preserve 1; swapaa /${14}:${15} ${16} preserve 1 ; swapaa /${17}:${18} ${19} preserve 1; swapaa /${20}:${21} ${22} preserve 1 ; swapaa /${23}:${24} ${25} preserve 1 ; swapaa /${26}:${27} ${28} preserve 1 ;swapaa /${29}:${30} ${31} preserve 1 ; save ${32}$4$3$7$6${10}$9${13}${12}${16}${15}${19}${18}${22}${21}${25}${24}${28}${27}${31}${30}."$output_format";')"

else

echo "Invalid input. Please provide arguments."
            exit 1
            fi


