#!/bin/bash

echo "===================================================================="
echo " Generate Individual Chimera compatible Minimization Python Scripts"
echo "===================================================================="

# Ask for folder with structure files
read -p "Enter full path to the folder with structure files (.pdb / .mol2 / .cif) (e.g., /mnt/d/chimera/minimization): " win_path

# Convert Windows-style path (C:\Users\...) to WSL path (/mnt/c/Users/...)
win_path=$(echo "$win_path" | sed 's|\\|/|g')                            
pdb_dir=$(echo "$win_path" | sed -E 's|^([A-Za-z]):|/mnt/\L\1|')       

# Find all supported structure files
shopt -s nullglob
structure_files=("$pdb_dir"/*.pdb "$pdb_dir"/*.mol2 "$pdb_dir"/*.cif)
shopt -u nullglob

if [ ${#structure_files[@]} -eq 0 ]; then
  echo "No .pdb, .mol2 or .cif files found in: $pdb_dir"
  exit 1
fi

# Loop through all files and generate Python script per structure
for file in "${structure_files[@]}"; do
  base=$(basename "$file")
  name="${base%.*}"
  output_py="$pdb_dir/minimize_${name}.py"

  # Convert to Windows-style path for Chimera (D:\\...\\file.format)
  file_win=$(echo "$file" | sed -E 's|/mnt/([a-zA-Z])|\U\1:|' | sed 's|/|\\\\|g')

  echo "Generating: $output_py"

  cat <<EOF > "$output_py"
import chimera
from chimera import runCommand

runCommand("open $file_win")
#runCommand("addh")			#uncomment to add hydrogen
#runCommand("addcharge")		#uncomment to add charges  
#runCommand("dockprep")			#uncomment to run dockprep
runCommand("minimize nsteps 2000")       #change the number of steps if needed

# Optional: Save minimized structure manually
# runCommand("write format pdb 0 ${file_win%.*}_min.pdb")
# runCommand("close all")
EOF

done

echo ""
echo "Chimera-compatible Python minimization scripts created in:"
echo "$pdb_dir"
echo "You can now open each 'minimize_*.py' script in Chimera for structure minimization."
