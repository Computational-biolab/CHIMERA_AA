#!/bin/bash
# CHIMERA_AA tool is designed by Dr.Pradeep Pant and Tushar Gupta.#
echo -e "CHIMERA_AA - Protein Mutation Tool (Chimera Compatible)\n"

# Ask user for input PDB and output format
read -p "Enter PDB ID (e.g., 1ABC) or full local path to PDB file (e.g., C:\\\\Users\\\\Desktop\\\\chimera_AA\\\\1ABC.pdb): " pdb_input
read -p "Enter the desired format of the output file(s) (.pdb / .cif / .mol2): " output_format

# Construct Chimera runCommand line
if [[ "$pdb_input" =~ ^[0-9a-zA-Z]{4}$ ]]; then
    pdb_input=$(echo "$pdb_input" | sed 's|\\|/|g')
    open_line="runCommand('open "$pdb_input"')"
else
    pdb_input=$(echo "$pdb_input" | sed 's|\\|/|g')
    open_line="runCommand('open "$pdb_input"')"
fi

echo -e "Enter '1' to perform mutations at single or multiple locations:\n\tTo generate user-specific mutations (maximum 10) in protein and their complexes (output: 1 file in the specified format)"
echo -e "Enter '2' to perform all possible class-wise amino-acid mutations at single or multiple locations:\n\tTo generate all combinations of user-specific class-wise amino-acid mutations (maximum 5 locations) in protein and their complexes (output: multiple files in the specified format)"

read -p "Enter your choice: " choice

# Display amino acid info
echo "
Protein:
               (Residue IDs)
            1  2  3  4  5  6  7  8  9 10 11 12
N-terminal  _  _  _  _  _  _  _  _  _  _  _  _  C-terminal  (ChainID: A)

#################################################################################################
# List of amino acids with their three letter codes (required as input)                         #
#                                                                                               #
# Alanine:        ALA      Arginine:      ARG      Asparagine:     ASN      Aspartic Acid:  ASP #
# Cysteine:       CYS      Glutamic Acid: GLU      Glutamine:      GLN      Glycine:        GLY #
# Histidine:      HIS      Isoleucine:    ILE      Leucine:        LEU      Lysine:         LYS #
# Methionine:     MET      Phenylalanine: PHE      Proline:        PRO      Serine:         SER #
# Threonine:      THR      Tryptophan:    TRP      Tyrosine:       TYR      Valine:         VAL #
#################################################################################################
"

# Start writing Python script
echo "import chimera" > CHIMERA_AA.py
echo "from chimera import runCommand" >> CHIMERA_AA.py
echo "$open_line" >> CHIMERA_AA.py

case $choice in

1)
echo "		  
Depending on the argument1, user can generate upto 10 mutations in a output file of a protein or their complexes

argument1:  Number of mutations you want to introduce

CASE 1. If argument1 = 1 (only one mutation)
	then argument2: mutate the residue to GLY/ALA/VAL/..etc: example ALA
	     argument3: perform mutation at residueID          : example 5
	     argument4: perform mutation at ChainID            : example A
	     argument5: location where you want the output file, example: "'C:\\Users\\Desktop\\TEST\\'"
      
      Overall Syntax (example): 1 ALA 5 A "'C:\\Users\\Desktop\\TEST\\'"

CASE 2. If argument1 = 3 (three mutations)
   For mutation1:
   	argument2:  mutate the residue to GLY/ALA/VAL/..etc   : example ALA
	argument3:  perform mutation at residueID             : example 5
	argument4:  perform mutation at ChainID               : example A
	
  (It means mutate whatever residue is there at resID 5 to ALA in chain A)

   For mutation2:
        argument5:  mutate the residue to GLY/ALA/VAL/..etc   : example GLY
        argument6:  perform mutation at residueID  	      : example 6
        argument7:  perform mutation at ChainID               : example A

   For mutation3:
        argument8:  mutate the residue to GLY/ALA/VAL/..etc   : example SER
        argument9:  perform mutation at residueID             : example 11
        argument10: perform mutation at ChainID               : example A
      argument11: location where you want the output file, example: "'C:\\Users\\Desktop\\TEST\\'"

    Overall Syntax (example): 3 ALA 5 A GLY 6 A SER 11 A "'C:\\Users\\Desktop\\TEST\\'"
"
read -r -a args
export output_format; ./multimf.sh "${args[@]}" "$output_format" >> CHIMERA_AA.py
;;

2)
echo "
Depending on the argument1, user can generate all possible class-wise amino-acid mutations at maximum 5 locations in output file(s) of a protein or their complexes

# Different classes of amino acid in CHIMERA_AA as defined in class.lib file.

#######################################################################################################
# List of amino acids with their three letter codes (required as input) along with their class        #
#                                                                                                     #
# HYDROPHOBIC (HYD)  AROMATIC      (ARO)   POLAR      (POL)   Basic     (BAS)   Acidic        (ACI)   #
# Alanine:     ALA   Phenylalanine: PHE    Serine:     SER    Lysine:    LYS    Aspartic Acid: ASP    #
# Valine :     VAL   Tyrosine:      TYR    Threonine:  THR    Arginine:  ARG    Glutamic Acid: GLU    #
# Leucine:     LEU   Tryptophan:    TRP    Cysteine:   CYS    Histidine: HIS                          #
# Isoleucine:  ILE                         Asparagine: ASN                                            #
# Glycine:     GLY                         Glutamine:  GLN                                            #
# Methionine:  MET                                                                                    # 
# Proline:     PRO                                                                                    #
#######################################################################################################

argument1: Number of locations (maximum 5) at which you would like to introduce all possible class-wise amino-acid mutations

CASE 1. If argument1 = 1 (only one mutation)
        then argument2: mutate the residue to ACI/POL/HYD/..etc : example POL
	     argument3: perform mutation at residueID           : example 5
	     argument4: perform mutation at ChainID             : example A
	     argument5: location where you want the output file, example: "'C:\\Users\\Desktop\\TEST\\'"
     
      Overall Syntax (example): 1 POL 5 A "'C:\\Users\\Desktop\\TEST\\'"

CASE 2. If argument1 = 3 (three mutations)
   For mutation1:
   	argument2:  mutate the residue to ACI/POL/HYD/..etc     : example ACI
	argument3:  perform mutation at residueID               : example 5
	argument4:  perform mutation at ChainID                 : example A
	
  (It means mutate whatever residue is there at resID 5 to ALA in chain A)

   For mutation2:
        argument5:  mutate the residue to ACI/POL/HYD/..etc     : example POL
        argument6:  perform mutation at residueID  	        : example 6
        argument7:  perform mutation at ChainID                 : example A

   For mutation3:
        argument8:  mutate the residue to ACI/POL/HYD/..etc     : example HYD
        argument9:  perform mutation at residueID               : example 11
        argument10: perform mutation at ChainID                 : example A
      argument11: location where you want the output file, example: "'C:\\Users\\Desktop\\TEST\\'"

    Overall Syntax (example): 3 ACI 5 A POL 6 A HYD 11 A "'C:\\Users\\Desktop\\TEST\\'"

"
read -r -a args
export output_format; ./combinationmf.sh "${args[@]}" "$output_format" >> CHIMERA_AA.py
;;

*)
    RED='\033[0;31m'
    NC='\033[0m'
    echo -e "${RED}Fatal Error: Please choose only among given options and enter '1' or '2'.${NC}"
    exit 1
    ;;
esac

echo "
Your Chimera executable Python script has been saved as: CHIMERA_AA.py

#################################################################################################################
# The code will automatically fetch your PDB structure from RCSB PDB when you enter the PDB ID  OR              #
# The code will import your pdb structure from the local system from the path you entered                       #
#                                                                                                               # 
# You may now execute your CHIMERA_AA.py file in Chimera 1.19 tool for applying desired mutations               #
# You may further execute the minimize.sh shell file using ./minimize.sh for obtaining python files to          #
# minimize your resulted structures by entering the path of folder in the mentioned template                    #
#################################################################################################################
"
